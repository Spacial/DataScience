#!/usr/bin/env python
### Parte 1: Exercitando 1
import string
from nltk import word_tokenize
from nltk.tokenize import RegexpTokenizer

def limpeza(sentence):
        sentence_raw = sentence.lower()
        tokenizer = RegexpTokenizer(r'\w+')
        sentence = "".join([i for i in sentence_raw if i not in string.punctuation])
        tokens = tokenizer.tokenize(sentence)
        return " ".join(tokens)

with open('dados/cv002_tok-3321.txt', 'r') as fneg:
    neg = fneg.readlines()

with open('dados/cv003_tok-8338.txt', 'r') as fpos:
    pos = fpos.readlines()

tdspalavras = []
plvs_neg = word_tokenize(limpeza(neg[0]))
plvs_pos = word_tokenize(limpeza(pos[0]))

tdspalavras = plvs_neg + plvs_pos

print(list(set(tdspalavras)))
