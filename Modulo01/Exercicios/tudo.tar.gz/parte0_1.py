#!/usr/bin/env python
### Parte 0: Exercitando 1
montecastelo = 'Ainda que falasse as línguas dos homens e falasse a língua dos anjos, sem amor eu nada seria.'

[print(x) for x in montecastelo]

listacastelo = montecastelo.split()

print(len(listacastelo))

[print(x) for x in listacastelo]

mundocastelo = montecastelo.replace('dos homens', 'dos mundos')

print(montecastelo[21:30])

print(montecastelo[-15:])

with open('montecastelo.txt', 'w') as f:
    f.write(montecastelo)

f.close()
