#!/usr/bin/env python
import nltk

from nltk import PorterStemmer, LancasterStemmer
from nltk import RSLPStemmer

from nltk import word_tokenize
#tokens =  ['coordenador', 'coordenando', 'coordenado', 'coordenação']
tokens =  ['wait', 'waiting', 'waited', 'waiter', 'waitress' ]

porter = PorterStemmer()
lanca = LancasterStemmer()
rs = RSLPStemmer()

for t in tokens:
        print(porter.stem(t))

for t in tokens:
        print(lanca.stem(t))

###
texto_en = 'My name is Maximus Decimus Meridius, commander of the armies of the north, General of the Felix legions and loyal servant to the true emperor, Marcus Aurelius. Father to a murdered son, husband to a murdered wife. And I will have my vengeance, in this life or the next (Gladiator, the movie).'
texto_pt = 'Meu nome é Maximus Decimus Meridius, comandante dos exércitos do norte, general das legiões de Félix e servo leal ao verdadeiro imperador, Marcus Aurelius. Pai de um filho assassinado, marido de uma esposa assassinada. E eu terei minha vingança, nesta vida ou na próxima (Gladiador, o filme).'

tokens_en = word_tokenize(texto_pt)

stem_text_porter = [porter.stem(p) for p in tokens_en]
stem_text_lancaster = [lanca.stem(p) for p in tokens_en]
stem_text_rslp = [rs.stem(p) for p in tokens_en]

print(stem_text_porter)
print(stem_text_lancaster)
print(stem_text_rslp)


