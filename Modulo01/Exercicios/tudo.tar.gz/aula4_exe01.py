#!/usr/bin/env python
import nltk

from nltk import PorterStemmer, LancasterStemmer
from nltk import RSLPStemmer
from nltk import word_tokenize
import pandas as pd 

porter = PorterStemmer()
lanca = LancasterStemmer()
rs = RSLPStemmer()

###
texto_mpbc = '''Mas eu ainda espero angariar as simpatias da opinião, e o primeiro
remédio é fugir a um prólogo explícito e longo. O melhor prólogo é o
que contém menos coisas, ou o que as diz de um jeito obscuro e
truncado. Conseguintemente, evito contar o processo extraordinário
que empreguei na composição destas Memórias, trabalhadas cá no
outro mundo. Seria curioso, mas nimiamente extenso, e aliás
desnecessário ao entendimento da obra. A obra em si mesma é tudo:
se te agradar, fino leitor, pago-me da tarefa; se te não agradar,
pago-te com um piparote, e adeus.

Algum tempo hesitei se devia abrir estas memórias pelo princípio ou
pelo fim, isto é, se poria em primeiro lugar o meu nascimento ou a
minha morte. Suposto o uso vulgar seja começar pelo nascimento,
duas considerações me levaram a adotar diferente método: a
primeira é que eu não sou propriamente um autor defunto, mas um
defunto autor, para quem a campa foi outro berço; a segunda é que
o escrito ficaria assim mais galante e mais novo. Moisés, que também
contou a sua morte, não a pôs no intróito, mas no cabo: diferença
radical entre este livro e o Pentateuco.
'''
tokens = word_tokenize(texto_mpbc)

stem_text_porter = [porter.stem(p) for p in tokens]
stem_text_lancaster = [lanca.stem(p) for p in tokens]
stem_text_rslp = [rs.stem(p) for p in tokens]

#print(stem_text_porter)
#print(stem_text_lancaster)
#print(stem_text_rslp)

comparativo = list(set(zip(stem_text_porter, stem_text_lancaster, stem_text_rslp)))

df_mpbc = pd.DataFrame(comparativo)

df_mpbc.columns=['Porter', 'Lancaster', 'RSLP']

print(df_mpbc)


