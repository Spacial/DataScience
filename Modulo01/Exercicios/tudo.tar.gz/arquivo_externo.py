#!/usr/bin/env python
import nltk
from nltk.corpus import CategorizedPlaintextCorpusReader

leitor = CategorizedPlaintextCorpusReader( r'/home/datascience/Text_Analisys/')

