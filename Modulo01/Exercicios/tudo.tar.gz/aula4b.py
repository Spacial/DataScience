#!/usr/bin/env python
import nltk
# nltk.download('averaged_perceptron_tagger')
# nltk.download('tagsets')
# nltk.download('maxent_ne_chunker')
# nltk.download('words')
from nltk import PorterStemmer, LancasterStemmer
from nltk import RSLPStemmer
from nltk import word_tokenize
import pandas as pd
import numpy as np

###
texto_en = 'Apple acquires Zoom in China on wednesday 6th may 2020. This news has made Apple and Google stock jump by 5% in the United States of America.' 
 
texto_pt = 'Apple adquire Zoom na China na quinta-feira 6 de maio de 2020. Essa notícia fez as ações da Apple e da Google subirem 5% nos Estados Unidos.'

tokens_pt = word_tokenize(texto_pt)
#print(tokens_en)

pos_tags = nltk.pos_tag(tokens_pt)
#print(pos_tags)

chunks = nltk.ne_chunk(pos_tags, binary=True)
#print(chunks)

entidades = []
rotulos = []

for c in chunks:
        if hasattr(c, 'label'):
                entidades.append(' '.join(chk[0] for chk in c) )
                rotulos.append(c.label())

print("#######")
print('NER - resultado')
#print(entidades)
#print(rotulos)

entidades_com_rotulos = list(set(zip(entidades, rotulos)))
#print(entidades_com_rotulos)

entidade_df = pd.DataFrame(entidades_com_rotulos)

entidade_df.colunms = ['Entidades', 'Rotulos']

print(entidade_df)
