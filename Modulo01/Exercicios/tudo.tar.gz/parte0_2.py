#!/usr/bin/env python
### Parte 0: Exercitando 2
import docx

romance = 'dados/ROMANCE.docx'

doc = docx.Document(romance)

texto = [p.text for p in doc.paragraphs]

print('total de parágrafos:', len(texto))

print('total de parágrafos:', texto[0])

print('total de parágrafos:', texto[3:6])

[print('Sim, "Machado" está no texto.') for p in texto if p.find('Machado') >= 0]

corrido = ''
for p in texto:
    corrido += p

jb = corrido.replace('Batista', 'João Batista')