#!/usr/bin/env python
### Parte 1: Exercitando 2
import nltk
from nltk import ngrams
import docx

arquivo = 'dados/Noticia_1.docx'
doc = docx.Document(arquivo)
noticia = [p.text for p in doc.paragraphs]
texto = ' '.join(noticia)

bigramas = []
trigramas = []

for ng in ngrams(texto.lower().split(), 2):
        bigramas.append(ng)

for ng in ngrams(texto.lower().split(), 3):
        trigramas.append(ng)

fdist_bi = nltk.FreqDist(bigramas)
fdist_tri = nltk.FreqDist(trigramas)

print('20 Bigramas mais frequentes:', fdist_bi.most_common(20))
print('20 Trigramas mais frequentes:', fdist_tri.most_common(20))
