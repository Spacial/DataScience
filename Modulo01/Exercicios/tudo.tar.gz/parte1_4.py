#!/usr/bin/env python
### Parte 1: Exercitando 4
import string
import re
import nltk
from nltk import ngrams, tokenize
from nltk.corpus import stopwords, machado
from nltk.tokenize import RegexpTokenizer
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def autolabel(rects, ax):
    """Attach a text label above each bar in *rects*, displaying its height."""
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom')


def plotpng(filename, data, graphlabel):
        fig = plt.figure(figsize = (10,4))
        fig, ax = plt.subplots(figsize=(10,10)) 
        labels = []
        freqs = []
        for d in data:
                labels.append(d[0])
                freqs.append(d[1])
        x = np.arange(len(labels))  
        width = 0.35  
        rects = ax.bar(x, freqs, width)

        ax.set_ylabel('Frequencia')
        ax.set_title(graphlabel)
        ax.set_xticks(x)
        plt.xticks(rotation=45)
        ax.set_xticklabels(labels)
        
        autolabel(rects, ax)

        fig.tight_layout()
        fig.savefig(filename, bbox_inches = "tight")
        return 


def plotall(filename, wordlist):
        fig = plt.figure(figsize = (10,4))
        fig, ax = plt.subplots(figsize=(10,10)) 
        fdist = nltk.FreqDist(wordlist)
        frequent_words = [[fdist[word], word] for word in set(wordlist) if len(word) > 4 and fdist[word]>= 5]
        sorted_word_frequencies = {}
        for item in sorted(frequent_words, reverse=True):
                sorted_word_frequencies[item[1]] = item[0] 

        labels = []
        freqs = []
        for d in sorted_word_frequencies:
                labels.append(' ')
                freqs.append(sorted_word_frequencies[d])
        x = np.arange(len(labels))  
        width = 0.55  
        ax.bar(x, freqs, width)

        ax.set_ylabel('Frequencia')
        ax.set_xlabel('Palavras maiores que 5 caracteres e com mais de 5 contagens.')
        ax.set_title('Gráfico de frequência geral \n $\it{filtrado conforme descrito no rótulo do eixo X.}$')

        plt.tick_params(
                axis='x',          # changes apply to the x-axis
                which='both',      # both major and minor ticks are affected
                bottom=False,      # ticks along the bottom edge are off
                top=False,         # ticks along the top edge are off
                labelbottom=False) # labels along the bottom edge are off

        fig.tight_layout()
        fig.savefig(filename, bbox_inches = "tight")
        return 


def preprocess(sentence, lang='english', filter=True):
        sentence_raw = sentence.lower()
        tokenizer = RegexpTokenizer(r'\w+')
        sentence = "".join([i for i in sentence_raw if i not in string.punctuation])
        tokens = tokenizer.tokenize(sentence)
        if filter:
                filtered_words = [w for w in tokens if not w in stopwords.words(lang)]
                return " ".join(filtered_words)
        else:
                return " ".join(tokens)


def dists(words, text):
        fdist_words = nltk.FreqDist(text)
        data = []
        for w in words:
                data.append(fdist_words[w])
        return data


def grams(n, lista):
        if type(lista) == str:
                lista = lista.lower().split()
        ret = []
        for ng in ngrams(lista, n):
                ret.append(ng)
        return ret 


def mac2raw(f):
        return [w for w in machado.words(f)]


def raw2token(text_raw, lang='english', filter=True):
        text = preprocess(' '.join(text_raw), lang, filter)
        return nltk.word_tokenize(text)


def machadao():
        print(' Exercicio 4:')
        print(' 1.', machado.readme())
        print(' 2. -\\ ')
        print('    a. ', machado.categories())
        print('    b. ', machado.fileids())
        print('    c. ', ' '.join(machado.words('romance/marm05.txt')))

### inicio do programa
machadao()

palavras = ['olhos', 'estado']
mpbc_raw = mac2raw('romance/marm05.txt')

mpbc_tok = raw2token(mpbc_raw, 'portuguese', False)
mpbc_dist = nltk.FreqDist(mpbc_tok)

mpbc_tok_filtered = raw2token(mpbc_raw, 'portuguese', True)
mpbc_dist_filtered = nltk.FreqDist(mpbc_tok_filtered)

print('    d.  palavras: ', palavras, ' no memoria postumas e: ', dists(palavras, ' '.join(mpbc_tok)))

print('    e. ', len(mpbc_raw))

print('    f. ', len(mpbc_dist.keys()), mpbc_dist.N())

print('    g. ', mpbc_dist.keys())

top15raw = mpbc_dist.most_common(15)
print('    h. ', top15raw)

print('    i. ')
mpbc_dist.tabulate(15)

print('    j. ', 'plotando em  mpbc_top15.png')
plotpng('mpbc_top15.png', top15raw, 'Top 15 termos mais repetidos')

top15filt = mpbc_dist_filtered.most_common(15)
print('    k - h. ', top15filt)

print('    k - i. ')
mpbc_dist_filtered.tabulate(15)

print('    k - j. ',  'plotando em  mpbc_top15_filtered.png')
plotpng('mpbc_top15_filtered.png', top15filt, 'Top 15 termos mais repetidos (filtrados)')

bigramas = grams(2, mpbc_tok_filtered)
trigramas = grams(3, mpbc_tok_filtered)

#print('    bi. ', len(bigramas))
print('    l. ', trigramas)

ojos = [l for l in bigramas if 'olhos' in l]
top15ojos = nltk.FreqDist(ojos)
print('    m. ', top15ojos.most_common(15))

print('    n. ',  'plotando em  mpbc_top15_olhos.png')
plotpng('mpbc_top15_olhos.png', top15ojos.most_common(15), 'Top 15 bigramas que contém $\it{olhos}$')

print('    o. ',  'plotando em  mpbc_all.png')
plotall('mpbc_all.png', mpbc_tok_filtered)
