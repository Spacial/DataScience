#!/usr/bin/env python
### Parte 1: Exercitando 3
import string
import re
import nltk
from nltk import ngrams, tokenize
from nltk.corpus import stopwords, webtext
from nltk.tokenize import RegexpTokenizer
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np


def autolabel(rects, ax):
    """Attach a text label above each bar in *rects*, displaying its height."""
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom')


def plotpng(filename, data):
        fig = plt.figure(figsize = (10,4))
        fig, ax = plt.subplots(figsize=(10,10)) 
        labels = ['the', 'that']
        pirates = data['pirates.txt']
        singles = data['singles.txt']
        x = np.arange(2)  
        width = 0.35  
        
        rects1 = ax.bar(x - width/2, pirates, width, label='Pirates.txt')
        rects2 = ax.bar(x + width/2, singles, width, label='Singles.txt')

        ax.set_ylabel('Frequencia')
        ax.set_title('Frequencias das palavras por arquivo')
        ax.set_xticks(x)
        ax.set_xticklabels(labels)
        ax.legend()
        autolabel(rects1, ax)
        autolabel(rects2, ax)
        fig.tight_layout()
        plt.show()
        fig.savefig(filename, bbox_inches = "tight")
        return 

def preprocess(sentence):
        sentence_raw = sentence.lower()
        tokenizer = RegexpTokenizer(r'\w+')
        sentence = "".join([i for i in sentence_raw if i not in string.punctuation])
        tokens = tokenizer.tokenize(sentence)
        filtered_words = [w for w in tokens if not w in stopwords.words('english')]
        return " ".join(filtered_words)


def dists(words, text):
        fdist_words = nltk.FreqDist(text)
        data = []
        for w in words:
                data.append(fdist_words[w])
        return data


def grams(n, lista):
        if type(lista) == str:
                lista = lista.lower().split()
        ret = []
        for ng in ngrams(lista, n):
                ret.append(ng)
        return ret 


def web2raw(f):
        return [w for w in webtext.words(f)]


def raw2token(text_raw):
        text = preprocess(' '.join(text_raw))
        return nltk.word_tokenize(text)


files = ['singles.txt', 'pirates.txt']
words = ['the', 'that']
toplot = {}

for f in files:
        text_raw = web2raw(f)
        freqs = dists(words, text_raw)
        print(' word: ', words, ' in file: ', f, ' has ->', freqs)
        tmpfreq = nltk.FreqDist(text_raw)
        data = []
        for w in words:
                data.append(tmpfreq[w])
        toplot[f] = data

for f in files:
        text_raw = web2raw(f)
        toktext = raw2token(text_raw)
        bigramas = grams(2, toktext)
        print(bigramas[:15])
        qgramas = grams(4, toktext)
        lifeg = [l for l in qgramas if 'life' in l]
        print(lifeg[:20])

plotpng('pirates_single.png', toplot)
